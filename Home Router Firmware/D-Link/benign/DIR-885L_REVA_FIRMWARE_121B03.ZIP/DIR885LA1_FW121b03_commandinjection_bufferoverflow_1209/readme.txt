issue :
	gena cgi command injection
	web file access services.c buffer overflow
	
ref : svn 84084, 84413